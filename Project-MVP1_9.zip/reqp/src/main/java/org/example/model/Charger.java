package org.example.model;

public class Charger {
    private String id;
    private String type;
    private Location location;

    public Charger(String id, String type, Location location) {
        this.id = id;
        this.type = type;
        this.location = location;
    }

    public String getId() { return id; }
    public String getType() { return type; }
    public Location getLocation() { return location; }

    @Override
    public String toString() {
        return "Charger{id='" + id + "', type='" + type + "', location=" + location + "}";
    }
}
