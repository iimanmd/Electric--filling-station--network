package org.example.manager;

import org.example.model.Location;
import java.util.*;

public class LocationManager {
    private Map<String, Location> locations = new HashMap<>();

    public void addLocation(Location location) {
        locations.put(location.getId(), location);
    }

    public Location getLocation(String id) {
        return locations.get(id);
    }

    public Collection<Location> getAllLocations() {
        return locations.values();
    }
}
