package org.example.manager;

import org.example.model.Charger;
import java.util.*;

public class ChargerManager {
    private Map<String, Charger> chargers = new HashMap<>();

    public void addCharger(Charger charger) {
        chargers.put(charger.getId(), charger);
    }

    public Charger getCharger(String id) {
        return chargers.get(id);
    }

    public Collection<Charger> getAllChargers() {
        return chargers.values();
    }
}
