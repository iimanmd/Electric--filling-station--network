package org.example.manager;

import org.example.model.Client;
import java.util.*;

public class ClientManager {
    private Map<String, Client> clients = new HashMap<>();

    public void addClient(Client client) {
        clients.put(client.getId(), client);
    }

    public Client getClient(String id) {
        return clients.get(id);
    }

    public Collection<Client> getAllClients() {
        return clients.values();
    }
}
