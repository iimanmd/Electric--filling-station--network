package steps;

import org.example.manager.LocationManager;
import org.example.model.Location;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;

public class LocationSteps {
    private LocationManager manager = new LocationManager();
    private Location location;

    @Given("a location with id {string} and name {string}")
    public void givenLocation(String id, String name) {
        location = new Location(id, name);
    }

    @When("I add the location to the system")
    public void addLocation() {
        manager.addLocation(location);
    }

    @Then("the location with id {string} should exist")
    public void locationShouldExist(String id) {
        Assertions.assertNotNull(manager.getLocation(id));
    }
}
