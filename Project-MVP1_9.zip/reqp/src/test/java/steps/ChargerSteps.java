package steps;

import org.example.manager.ChargerManager;
import org.example.manager.LocationManager;
import org.example.model.Charger;
import org.example.model.Location;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;

public class ChargerSteps {
    private ChargerManager chargerManager = new ChargerManager();
    private LocationManager locationManager = new LocationManager();
    private Charger charger;
    private Location location;

    @Given("a charger with id {string}, type {string}, and location {string}")
    public void givenCharger(String id, String type, String locationId) {
        location = new Location(locationId, "Some Place");
        locationManager.addLocation(location);
        charger = new Charger(id, type, location);
    }

    @When("I add the charger to the system")
    public void addCharger() {
        chargerManager.addCharger(charger);
    }

    @Then("the charger with id {string} should exist")
    public void chargerShouldExist(String id) {
        Assertions.assertNotNull(chargerManager.getCharger(id));
    }
}
