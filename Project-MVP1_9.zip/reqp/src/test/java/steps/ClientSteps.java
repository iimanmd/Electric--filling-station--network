package steps;

import org.example.manager.ClientManager;
import org.example.model.Client;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;

public class ClientSteps {
    private ClientManager manager = new ClientManager();
    private Client client;

    @Given("a client with id {string} and name {string}")
    public void givenClient(String id, String name) {
        client = new Client(id, name);
    }

    @When("I add the client to the system")
    public void addClient() {
        manager.addClient(client);
    }

    @Then("the client with id {string} should exist")
    public void clientShouldExist(String id) {
        Assertions.assertNotNull(manager.getClient(id));
    }
}
