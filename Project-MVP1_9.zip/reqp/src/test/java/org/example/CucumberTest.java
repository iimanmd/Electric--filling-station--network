package org.example;

import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
public class CucumberTest {
}
