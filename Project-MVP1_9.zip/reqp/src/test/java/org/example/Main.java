package org.example;

import org.example.manager.ChargerManager;
import org.example.manager.ClientManager;
import org.example.manager.LocationManager;
import org.example.model.Charger;
import org.example.model.Client;
import org.example.model.Location;

public class Main {
    public static void main(String[] args) {
        ClientManager clientManager = new ClientManager();
        LocationManager locationManager = new LocationManager();
        ChargerManager chargerManager = new ChargerManager();

        Client client = new Client("C001", "Alice");
        clientManager.addClient(client);

        Location location = new Location("L001", "City Center");
        locationManager.addLocation(location);

        Charger charger = new Charger("CH001", "AC", location);
        chargerManager.addCharger(charger);

        System.out.println("Clients: " + clientManager.getAllClients());
        System.out.println("Locations: " + locationManager.getAllLocations());
        System.out.println("Chargers: " + chargerManager.getAllChargers());
    }
}
